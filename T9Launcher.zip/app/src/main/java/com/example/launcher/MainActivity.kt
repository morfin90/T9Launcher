package com.example.launcher
// ... (فایل کامل پیش‌تر توضیح داده شد)
