package com.example.launcher.models
// ... (فایل کامل پیش‌تر توضیح داده شد)
